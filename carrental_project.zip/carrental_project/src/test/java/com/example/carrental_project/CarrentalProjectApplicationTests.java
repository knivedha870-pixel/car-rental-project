package com.example.carrental_project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarrentalProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
